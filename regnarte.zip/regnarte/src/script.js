// Dans la classe HyperMemory
applyForces(memories) {
    memories.forEach(other => {
        if (other === this) return;
        
        // Distance 4D (simplifiée)
        const dx = other.position.x - this.position.x;
        const dy = other.position.y - this.position.y;
        const dz = other.position.z - this.position.z;
        const dw = other.position.w - this.position.w;
        const dist = Math.sqrt(dx*dx + dy*dy + dz*dz + dw*dw);
        
        // Force basée sur la similarité de couleur
        const hueDiff = Math.abs(this.hue - other.hue);
        const force = (hueDiff < 60) ? -0.1 : 0.1; // Répulsion ou attraction
        
        // Appliquer la force
        this.velocity.x += (dx / dist) * force;
        this.velocity.y += (dy / dist) * force;
        // (...)
    });
}